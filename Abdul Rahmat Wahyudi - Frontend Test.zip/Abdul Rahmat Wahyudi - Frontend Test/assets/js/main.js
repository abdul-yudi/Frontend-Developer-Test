(function(){

	// Declaring elements
	const elm = {
		container: document.querySelector('.container'),
		notification: document.querySelector('.notification'),
		newsletter: document.querySelector('.newsletter'),
		notifButton: document.querySelector('.notification__button'),
		newsletterClose: document.querySelector('.newsletter__close')
	};

	/* Showing Newsletter when page scrolled to bottom */
	window.addEventListener('scroll', function(){
		let scrolled = window.pageYOffset;
		let coords = document.documentElement.clientHeight - 350;

		if (scrolled > coords) {
			elm.newsletter.classList.add('showToTop');
		};
	});

	/* Close Notification */
	elm.notifButton.addEventListener('click', function(){
		elm.notification.classList.add('hideToTop');
		elm.container.classList.add('slideToTop');
	});

	/* Close Newsletter */
	elm.newsletterClose.addEventListener('click', function(){
		elm.newsletter.classList.add('hideToBottom');

		/* Showing Newsletter again after 10 minutes */
	  let showNewsletter = setInterval(function() {
			clearInterval(showNewsletter);
	    elm.newsletter.classList.remove('hideToBottom');
	  }, 600000);
	});

})();